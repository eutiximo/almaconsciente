<?php

//Definir contexto de Timber
$context = Timber::get_context();

//Añadir al contexto la información de la "página INICIO"
$context["post"] = $post = new Timber\Post("inicio");

//Posts para la seccion de diapositivas
$context["slidePosts"] = $slidePosts = Timber::get_posts(array(
    "meta_query" => array(
        "relation" => "AND",
        array(
            "key" => "append_slide_home",
            "value" => 1
        )
    )
));

//Obtener las ultimas 3 publicaciones.
$context["lastPosts"] = $lastPosts = Timber::get_posts(array("posts_per_page" => 3));

//Definir la clase de main -> esto sirve para las hojas de estilo.
$context["nameClass"] = "home";

$MC->debug($slidePosts);

//Renderear página.
$MC->renderSite(array("index.twig"), $context);

?>  