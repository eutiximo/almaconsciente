var console, document, window, $g;

(function () {
    "use strict";
    
    $g = {
        page: {}
    };
    
    $g.owl = {
        sets: {
            default: {
                items: 1,
                loop: true,
                nav: true,
                dots: true,
                navText: ["<span></span>", "<span></span>"]
            }
        },
        
        model: function (Elem) {
            var self = this,
                getSet = Elem.attr("owl") || "default",
                getTarget = Elem.attr("owl-target") || "self",
                hasFitContainer = Elem[0].hasAttribute("fit-content"),
                set = self.sets[getSet] || {};
            
            if (hasFitContainer) {
                let Items = Elem.find(".item");
                
                Items.css("height", window.innerHeight);
                $(window).on("resize", function () { Items.css("height", window.innerHeight); })
            }
            
            if (getTarget === "self") {
                Elem.owlCarousel(set);
            } else {
                Elem.find(getTarget).owlCarousel(set);
            }
        },
        
        init: function () {
            var self = this,
                Elems = $("[owl]");
            
            if (Elems.length) Elems.each(function (i, elem) { self.model($(this)); });
        }
    };
    
    $g.include = function () {
        var Elem = $("[include]");
        
        Elem.each(function (i, elem) {
            var currentElem = $(this),
                getSrc = currentElem.attr('include');
            
            getSrc = getSrc === "" ? "/undefined" : getSrc;
            
            $.get(getSrc, function (response) {
                currentElem.html(response);
            }, 'text').fail(function () {
                currentElem.html("<i style='display:block;text-align:center;font-size:0.7rem'>Error load include</i>").css({"border": "1px solid red", "color": "red"});
            });
        });
    };
    
    $g.page.inicio_contacto = function () {
        
    };
    
    /* Document Ready */
    $(function () {
        $g.owl.init();
        $g.include();
    });
})();